# DESCRIPTION:
#
# You can use query to invoke a command and cache its stdout into
# QUERY associative array. If you later invoke the same query (with
# the same command), the presence of the cached result is discovered
# and the command is not invoked again. This can be used to save time
# and ensure the same command gives the same answer across many macro
# invocations. Note that query caches the command even if it returns a
# non-zero status. It will, however, return a non-zero status as well
# upon the first command invocation (see the implementation below).
#
# EXAMPLE:
#
#     source query.bash
#
#     query git status "$path" # calls git status "$path"
#     url1="${QUERY["git status $path"]%$'\n'}"
#
#     query git status "$path" # does nothing
#     url2="${QUERY["git status $path"]%$'\n'}"
#
#     [ "$url1" = "$url2" ] && echo "always printed."
#
# It is preferred that you instead bootstrap the shared state
# when the macro script is sourced because it is much easier
# to read and understand afterwards.

declare -Ax QUERY

function query {
    if [ -z "${QUERY["$*"]+set}" ]; then
        IFS_BACK="$IFS"
        IFS= read -rd '' QUERY["$*"] < <(IFS="$IFS_BACK" "$@" && printf '\0') # printf '\0' for read to return zero if the command suceeded
    fi
}
