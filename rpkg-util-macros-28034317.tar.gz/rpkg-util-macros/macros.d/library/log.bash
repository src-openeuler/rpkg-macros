# DESCRIPTION:
#
# Logging framework for rpkg macros.
#
# All logs go to stderr because stdout is reserved
# for macro output.
#
# EXAMPLE:
#
#      source log.bash
#      log_error "unexplainable error."

function log_debug {
    if [ -n "$VERBOSE" ]; then
        log msg="$*"
    fi
}

function log_info {
    log msg="$*"
}

function log_error {
    log prefix=ERROR msg="$*"
}

function log {
    declare prefix= msg= "$@"

    regexp="^\s*$"
    if [[ "$msg" =~ $regexp ]]; then
        return
    fi

    # older bashes (e.g. bash 4.1.2) do not support negative array indeces.
    # we check for != "main" for the case a macro is invoked directly from command line.
    if [ "${FUNCNAME[*]: -1}" != "main" ]; then
        echo "${prefix:+$prefix: }${FUNCNAME[*]: -1}: $msg"
    else
        echo "${prefix:+$prefix: }${FUNCNAME[*]: -2: 1}: $msg"
    fi > /dev/stderr
}
