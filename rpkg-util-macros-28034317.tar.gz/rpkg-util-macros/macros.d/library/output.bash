# DESCRIPTION:
#
# output function provided here prints its input parameters as a
# single string. In addition, it also caches the string into OUTPUT
# associative array, so that you can later access it under name of
# the function that invoked output. It is assummed you invoke output
# only once at the end of a function to print result of a computation.
#
# EXAMPLE:
#
#     source output.bash
#
#     function foo {
#         output "result"
#     }
#
#     foo
#     echo "${OUTPUT[foo]}"

declare -Ax OUTPUT

function output {
    OUTPUT["${FUNCNAME[1]}"]="$*"
    echo "${OUTPUT[${FUNCNAME[1]}]}"
}
