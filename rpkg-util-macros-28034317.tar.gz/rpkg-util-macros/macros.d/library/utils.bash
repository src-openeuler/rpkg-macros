# DESCRIPTION:
#
# Set of various utility functions that
# are rather generic.

function utils_encode_decimal {
    radixdigits=({a..z} {0..9})
    x="$1"
    result=
    while [ "$x" -gt 0 ]; do
        div=$(($x/${#radixdigits[@]}))
        mod=$(($x-$div*${#radixdigits[@]}))
        result="${radixdigits[$mod]}${result}"
        x="$div"
    done
    echo -n "$result"
}
