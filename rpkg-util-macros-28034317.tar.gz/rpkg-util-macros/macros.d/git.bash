# DESCRIPTION:
#
# This file provides set of preproc macros that you can use
# in an rpm spec file to dynamically generate its parts based
# on git metadata and content.
#
# The macros need to know INPUT_DIR_PATH, which is directory where
# the input spec file is located. If this variable is unset or empty
# it will be derived from INPUT_PATH. If INPUT_PATH is also unset or
# empty, INPUT_DIR_PATH will default to . (the only purpose of this
# default is to allow for easy experimentation with the macros on
# command-line).
#
# If git repo is dirty (non-empty GIT_DIRTY), we make it obvious
# in version strings and we are allowed to operate on the dirty
# (uncommitted) content.
#
# If git repo is clean (empty GIT_DIRTY), we can only operate
# on the commit content specified by GIT_HEAD environment variable.
# Work tree (+index) becomes irrelevant except for git prefix
# invocations to convert path params into prefixes which are
# then checked for their presence in GIT_HEAD tree.
#
# Untracked content is ignored in either case.
#
# "Dirty mode" is good for debugging and local development.
#
# We provide default values for all GIT_* params passed by rpkg,
# to be able to source and run the macros directly on command line
# for debugging purposes.
#
# We do reference all git objects (commits, tags) by their SHAs,
# which should be unique. We don't reference objects for which we
# do not hold SHAs beforehand. That prevents accessing objects
# that are possibly added in the middle of macro processing.
#
# We ignore lightweight tags.
#
# We support git up from 1.7.1. Please, if you see something
# for which there is a better git-command alternative, first
# consider if the alternative is available in the older gits.
# Example is usage of basename in git_branch helper script
# instead of just `git symbolic-ref --short`.
#
# If the file is sourced outside of any git repository, it
# should produce no error output, until any macro is invoked.
#
# The best way to determine whether an (s)rpm was generated
# from a clean tree is to look at its VCS: tag if provided,
# parse out the fragment part (following '#') and split on ':'.
# If the first part of the split is non-empty, then it should
# contain sha of the commit from which the (s)rpm was generated.
# If it is empty, then it was generated from a dirty tree and
# content can be anything. git_vcs macro below generates the
# value for the VCS: tag accordingly. This is a proposed
# convention that would like some cooperation of packagers.
#
# Clean (s)rpms should also be signed by a key you trust. If
# you then read out the VCS tag, you should get a trustworthy
# information about the real source of the package.
#
# For a clean tree, the originating commit sha will be also
# present in tar headers for each dynamically generated source
# by git_pack or git_archive macros and can be extracted with
# git get-tar-commit-id.
#
# In the code, we aim for early exit in case of any failure.
# For assignments such as: var="$(<pipeline>)", this is complicated
# because we don't have an easy access to return codes of the
# commnds executed in the pipeline and also a command after
# pipe can read only part of input a then close the pipe,
# resulting in SIGPIPE for the commnd before the pipe.
# However if you work with commands that read all the input
# and that return error codes on actual failures, preferred
# error handling in a function is:
# var="$(set -o pipefail; <pipeline>)" || return
#
# There is "query" mechanism provided (see helpers/query.bash)
# to cache a stdout of a command invocation for use in another
# macro if that macro needs to invoke the same command with the
# same parameters. Try to avoid using it unless it brings real
# benefits and there is no other way around.

srcdir="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATH="$srcdir/helpers:$PATH"

source "$srcdir/library/log.bash"
source "$srcdir/library/utils.bash"
source "$srcdir/library/output.bash"

############## ENVIRONMENT VARIABLES ##############

declare -x INPUT_PATH                # path to file with macros being processed
declare -x INPUT_DIR_PATH            # path to input file's directory
declare -x VERSION_BUMP              # do we bump version
declare -x RELEASE_BUMP              # do we bump release
declare -x VERBOSE                   # verbosity level
declare -x OUTDIR                    # where to put output files

declare -x GIT_VERSION               # git version
declare -x GIT_LEGACY                # do we deal with v1 git

declare -x GIT_ROOT                  # path to git repo we operate on
declare -x GIT_STATUS                # changes in work tree and staging area
declare -x GIT_BRANCH                # branch we operate on
declare -x GIT_REMOTE                # remote for the branch or origin
declare -x GIT_REMOTE_URL            # remote url for the branch
declare -x GIT_HEAD                  # commit we operate on
declare -x GIT_HEAD_SHORT            # the commit's short sha
declare -x GIT_MERGED_TAG_REFS_FILE  # file with merged <sha> <tagname> pairs sorted by rpm-git-tag-sort
declare -x GIT_MERGED_TAG_REFS       # merged <sha> <tagname> pairs sorted by rpm-git-tag-sort
declare -x GIT_SUBMODULE_REFS_FILE   # file with <head sha> <path> pairs for all submodules in topologically reversed order
declare -x GIT_SUBMODULE_REFS        # <head sha> <path> pairs for all submodules in topologically reversed order
declare -x GIT_DIRTY                 # non-empty if repo is dirty

# NOTE: dirname '' gives .
INPUT_DIR_PATH="${INPUT_DIR_PATH-$(dirname "$INPUT_PATH")}"

GIT_VERSION="${GIT_VERSION-$(/usr/bin/git --version)}"
GIT_LEGACY="${GIT_LEGACY-$(echo "$GIT_VERSION" | grep 'git version 1')}"

GIT_ROOT="${GIT_ROOT-$(git_root "$INPUT_DIR_PATH" 2>/dev/null)}"
GIT_HEAD="${GIT_HEAD-$(GIT_ROOT="$GIT_ROOT" git_head 2>/dev/null)}"
GIT_HEAD_SHORT="${GIT_HEAD_SHORT-$(GIT_ROOT="$GIT_ROOT" GIT_HEAD="$GIT_HEAD" git_head_short 2>/dev/null)}"
GIT_BRANCH="${GIT_BRANCH-$(GIT_ROOT="$GIT_ROOT" git_branch 2>/dev/null)}"
GIT_REMOTE="${GIT_REMOTE-$(GIT_ROOT="$GIT_ROOT" GIT_BRANCH="$GIT_BRANCH" git_remote 2>/dev/null)}"
GIT_REMOTE_URL="${GIT_REMOTE_URL-$(GIT_ROOT="$GIT_ROOT" GIT_REMOTE="$GIT_REMOTE" git_remote_url 2>/dev/null)}"
GIT_STATUS="${GIT_STATUS-$([ -f "$GIT_STATUS_FILE" ] && cat "$GIT_STATUS_FILE" \
    || GIT_ROOT="$GIT_ROOT" git_status 2>/dev/null)}"
GIT_MERGED_TAG_REFS="${GIT_MERGED_TAG_REFS-$([ -f "$GIT_MERGED_TAG_REFS_FILE" ] && cat "$GIT_MERGED_TAG_REFS_FILE" \
    || GIT_ROOT="$GIT_ROOT" GIT_HEAD="$GIT_HEAD" git_merged_tag_refs 2>/dev/null)}"
GIT_SUBMODULE_REFS="${GIT_SUBMODULE_REFS-$([ -f "$GIT_SUBMODULE_REFS_FILE" ] && cat "$GIT_SUBMODULE_REFS_FILE" \
    || GIT_ROOT="$GIT_ROOT" GIT_HEAD="$GIT_HEAD" git_submodule_refs 2>/dev/null)}"
GIT_DIRTY="${GIT_DIRTY-$([ -n "$GIT_STATUS" ] || { [ -n "$GIT_ROOT" ] && [ -z "$GIT_HEAD" ]; } && echo 1)}"

if [ -z "$GIT_LEGACY" ]; then
    git=/usr/bin/git
else
    git=git
fi

############## HELPERS ##############

function is_physical_subpath {
    # we need "$2" = "/" because centos7 bash doesn't handle ${2%/}" when "$2" is just /, it replaces "${2%/}" with 0x7F char
    if [[ "$2" = "/" || "${1%/}" = "${2%/}" || "${1%/}" = "${2%/}"/* ]]; then
        return 0
    fi
    return 1
}

function is_strict_physical_subpath {
    # does not accept equality, we are work-arounding the centos7 bug here as well
    if [[ "$2" = "/" && "$1" = /?* || "${1%/}" = "${2%/}"/* ]]; then
        return 0
    fi
    return 1
}

function git_check_path {
    git_check_repo || return

    if [ -z "$1" ]; then
        log_error "path cannot be empty."
        return 1
    fi

    if ! [ -d "$1" ]; then
        log_error "path is not a directory."
        return 1
    fi

    if ! is_physical_subpath "$(git_root "$1")" "$GIT_ROOT"; then
        log_error "path outside of $GIT_ROOT."
        return 1
    fi

    if [ -z "$GIT_DIRTY" ]; then
        path_prefix="$("$git" -C "$1" rev-parse --show-prefix)"
        if ! "$git" -C "$GIT_ROOT" rev-parse "$GIT_HEAD:$path_prefix" &>/dev/null; then
            log_error "path is not tracked in $GIT_HEAD_SHORT."
            return 1
        fi
    fi
}

function git_check_repo {
    if [ -z "$GIT_ROOT" ]; then
        log_error "Not a Git repository."
        return 1
    fi

    if ! [ -d "$GIT_ROOT" ]; then
        log_error "$GIT_ROOT is not a directory."
        return 1
    fi

    if [ "$GIT_ROOT" != "$("$git" -C "$GIT_ROOT" rev-parse --show-toplevel 2>/dev/null)" ]; then
        log_error "$GIT_ROOT is not a Git repository top-level."
        return 1
    fi
}

function trim_slashes {
    sed -e 's|^/||' -e 's|/$||'
}

function git_prefix_to_name_prefix {
    sed -e 's|//*|-|g' -e 's|\([^-]\)$|-\1|' -e 's|^-||'
}

function git_prefix_to_name_suffix {
    sed -e 's|//*|-|g' -e 's|^\([^-]\)|-\1|' -e 's|-$||'
}

function git_tag_ref_filter {
    grep -E "^[a-f0-9]+\s+${1}$"
}

function git_formatted_changelog_body {
    declare body= body_wrap= "$@"

    formatted_body="$(set -o pipefail; echo "$body" | fold -cs --width="$body_wrap" | sed -E -e 's/(\s+)%([^%])/\1%%\2/g' -e 's/\s*$//')" || return
    echo "$formatted_body"
}

function git_formatted_changelog_record {
    declare verrel= tag_id= header_locale= header_date_format= body_wrap= "$@"

    body="$("$git" -C "$GIT_ROOT" for-each-ref --points-at="$tag_id" --format='%(contents:body)')" || return
    if [ -z "$body" ]; then
        body="(none)"
    fi

    if [ -n "$header_date_format" ]; then
        header_date_format_suffix=":format:$header_date_format"
    else
        header_date_format_suffix=
    fi
    header="$(LC_ALL="$header_locale" "$git" -C "$GIT_ROOT" for-each-ref --points-at="$tag_id" \
        --format="* %(taggerdate$header_date_format_suffix) %(taggername) %(taggeremail)") $verrel" || return

    formatted_body="$(git_formatted_changelog_body body="$body" body_wrap="$body_wrap")" || return
    echo "${header}"$'\n'"${formatted_body}"
}

function git_formatted_changelog_record_legacy {
    declare verrel= header_locale= header_date_format= body_wrap= "$@"

    data="$("$git" -C "$GIT_ROOT" cat-file tag "$tag_id")" || return

    # split file_data by empty lines into header, subject, and body
    i=0
    s=1
    declare -a arr
    while read -r line
    do
        # If we find an empty line, then we increase the counter (i),
        # set the flag (s) to one, and skip to the next line
        [ -z "$line" ] && ((++i)) && s=1 && continue
        # If the flag (s) is zero, then we are not in a new line of the block
        # so we set the value of the array to be the previous value concatenated
        # with the current line
        [ "$s" = 0 ] && arr[$i]="${arr[$i]}"$'\n'"${line}" || {
            # Otherwise we are in the first line of the block, so we set the value
            # of the array to the current line, and then we reset the flag (s) to zero
            arr[$i]="$line"
            s=0;
        }
    done <<< "$data"

    header="${arr[0]}"
    subject="${arr[1]}"
    body="${arr[2]:-(none)}"

    IFS=, read -r taggername taggeremail taggerdate <<< "$(echo "$header" | sed -E -n 's/^tagger\s+([^<]*)\s+(<.*>)\s+([0-9]+)\s+.*$/\1,\2,\3/p')"

    header_date="$(LC_ALL="$header_locale" date --date "@$taggerdate" +"$header_date_format")" || return
    header="* $header_date $taggername $taggeremail $verrel"

    formatted_body="$(git_formatted_changelog_body body="$body" body_wrap="$body_wrap")" || return
    echo "${header}"$'\n'"${formatted_body}"
}

function git_bumped_version {
    declare lead= follow= "$@"

    # if empty follow but non-empty numeric lead greater than zero, output ${lead}.0
    if [ -z "$follow" ] && [ -n "$lead" ] && [[ "$lead" != *[!0-9]* ]] && [ "$lead" -gt 0 ]; then
        echo "${lead}.0"
        return
    fi

    if echo "$follow" | grep -q '[^0-9]'; then
        log_error "$follow is not a number. Please, bump version manually."
        return 1
    fi

    bumped_follow=$(( follow + 1 ))
    echo "${lead:+$lead.}${bumped_follow}"
}

function git_revlist_since {
    "$git" -C "$GIT_ROOT" rev-list "$1..$GIT_HEAD"
}

function git_revlist {
    "$git" -C "$GIT_ROOT" rev-list "$GIT_HEAD"
}

function git_prefix {
    path_git_root="$(git_root "$1")"
    super_prefix="$(echo "${path_git_root#${GIT_ROOT%/}}" | trim_slashes)"
    prefix="$("$git" -C "$1" rev-parse --show-prefix)" || return
    echo "${super_prefix}/${prefix}" | trim_slashes
}

function git_version_dirty_appendix {
    if [ -z "$GIT_DIRTY" ]; then
        return
    fi

    latest_ctime="$(git_latest_ctime)" || return
    if [ "$latest_ctime" -ne 0 ]; then
        dirty_appendix=".dirty.$(utils_encode_decimal "$latest_ctime")" || return
    else
        dirty_appendix=".dirty"
    fi

    echo "$dirty_appendix"
}

function git_version_appendix {
    if [ -n "$1" ]; then
        commit_count="$(set -o pipefail; git_revlist_since "$1" | wc -l)" || return
    else
        commit_count="$(git_revlist 2>/dev/null | wc -l || printf 0)"
    fi

    if [ "$commit_count" -eq 0 ]; then
        commit_count_appendix=
    else
        commit_count_appendix=".git.$commit_count.$GIT_HEAD_SHORT"
    fi

    version_appendix="${commit_count_appendix}$(git_version_dirty_appendix)" || return

    if [ -n "$version_appendix" ]; then
        echo "$version_appendix"
    fi
}

function git_url_path_name {
    basename="$(basename "$GIT_REMOTE_URL")"

    if [ -z "$basename" ]; then
        return
    fi

    suffix="$(set -o pipefail; git_prefix "$1" | git_prefix_to_name_suffix)" || return
    echo "${basename%.git}${suffix}"
}

function git_latest_ctime {
    latest_ctime=0
    while read -r f; do
        if [ -n "$f" ] && [ -e "$GIT_ROOT/$f" ]; then
            ctime=$(stat --format='%Z' "$GIT_ROOT/$f") || return
            if [ "$ctime" -gt "$latest_ctime" ]; then
                latest_ctime="$ctime"
            fi
        fi
    done < <(echo "$GIT_STATUS" | cut -c 4- | sed -E 's|(.*) -> (.*)|\1\n\2|')
    echo "$latest_ctime"
}

function git_module_head_path {
    while read -r module_head module_path; do
        if [ -n "$module_head" ] && is_physical_subpath "$(git_root $1)" "$module_path"; then
            echo "$module_head $module_path"
            break
        fi
    done < <(echo "$GIT_SUBMODULE_REFS")
}

function git_version_filter {
    declare lead= "$@"

    if [ -z "$lead" ]; then
        echo "[^-]+"
    else
        echo "${lead}\.[^.-]*"
    fi
}

function git_version_generic {
    declare name="${OUTPUT[git_name]}" lead= follow= bump= filter_re= version_re= "$@"

    git_check_repo || return

    if [ -z "$name" ]; then
        log_error "name cannot be empty."
        return 1
    fi

    if echo "$lead" | grep -q '-'; then
        log_error "lead cannot contain dashes."
        return 1
    fi

    if echo "$follow" | grep -q '[.-]'; then
        log_error "follow cannot contain dots or dashes."
        return 1
    fi

    latest_tag_ref="$(echo "$GIT_MERGED_TAG_REFS" | git_tag_ref_filter "${filter_re}" | head -1)"
    read -r latest_tag_id latest_tag_name <<< "$latest_tag_ref"
    latest_tag_version="$(echo "$latest_tag_name" | sed -E -n "s/^${version_re}$/\1/p")"

    if [ -z "$lead" ]; then
        lead="$(echo "$latest_tag_version" | sed -E -n "s/^(.*)\.[^.]*$/\1/p")"
    fi

    if [ -n "$follow" ]; then
        if [ -n "$bump" ]; then
            echo "${lead:+$lead.}${follow}"
        else
            version_appendix=$(git_version_appendix "$latest_tag_id") || return
            echo "${lead:+$lead.}${follow}${version_appendix}"
        fi
        return
    fi

    follow="$(echo "$latest_tag_version" | sed -E -n "s/^${lead:+$lead\.}([^.]*)$/\1/p")"

    if [ -n "$bump" ]; then
        version="$(git_bumped_version lead="$lead" follow="$follow")" || return
        echo "$version"
        return
    fi

    version_appendix="$(git_version_appendix "$latest_tag_id")" || return
    echo "${lead:+$lead.}${follow:-0}${version_appendix}"
}

############## BASE FUNCTIONS ##############

function git_name {
    declare name= prepend= append= "$@"

    if [ -n "$name" ]; then
        output "${prepend}${name}${append}"
        return
    fi

    git_check_repo || return

    if [ -z "$GIT_REMOTE_URL" ]; then
        log_error "Could not get remote URL."
        return 1
    fi

    url_last_part="$(basename "$GIT_REMOTE_URL")"
    name="${url_last_part%.git}"

    output "${prepend}${name}${append}"
}

function git_version {
    declare name="${OUTPUT[git_name]}" lead=0 follow= "$@"

    version_filter="$(git_version_filter lead="$lead")"

    version="$(git_version_generic name="$name" lead="$lead" follow="$follow" bump="$VERSION_BUMP" \
        filter_re="${name}-${version_filter}-[^-]+" version_re="${name}-([^-]+)-[^-]+" "$@")" || return

    output "$version"
}

function git_release {
    declare name="${OUTPUT[git_name]}" lead= follow= "$@"

    version_filter="$(git_version_filter lead="$lead")"

    version="$(git_version_generic name="$name" lead="$lead" follow="$follow" bump="$RELEASE_BUMP" \
        filter_re="${name}-[^-]+-${version_filter}" version_re="${name}-[^-]+-([^-]+)" "$@")" || return

    output "$version"
}

function git_release_branched {
    git_release lead="$GIT_BRANCH" "$@"
}

function git_changelog {
    declare name="${OUTPUT[git_name]}" since_tag= until_tag= header_locale=POSIX header_date_format="%a %b %d %Y" body_wrap=80 "$@"

    git_check_repo || return

    if [ -z "$name" ]; then
        log_error "name cannot be empty."
        return 1
    fi

    changelog=
    until_tag_hit=
    while read -r tag_id tag_name; do
        if [ -n "$until_tag" ] && [ -z "$until_tag_hit" ] && [ "$until_tag" != "$tag_name" ]; then
            continue
        fi
        until_tag_hit=1

        verrel="$(echo "$tag_name" | sed -E -n "s/^${name}-([^-]+)(-[^-]+)$/\1\2/p")"

        if [ -z "$GIT_LEGACY" ]; then
            formatted_record="$(git_formatted_changelog_record \
                verrel="$verrel" tag_id="$tag_id" header_locale="$header_locale" header_date_format="$header_date_format" body_wrap="$body_wrap")" || return
        else
            formatted_record="$(git_formatted_changelog_record_legacy \
                verrel="$verrel" header_locale="$header_locale" header_date_format="$header_date_format" body_wrap="$body_wrap")" || return
        fi

        if [ -n "$changelog" ]; then
            changelog="$changelog"$'\n\n'
        fi

        changelog="${changelog}${formatted_record}"

        if [ "$since_tag" = "$tag_name" ]; then
            break
        fi
    done < <(echo "$GIT_MERGED_TAG_REFS" | git_tag_ref_filter "${name}-[^-]+-[^-]+")

    output "$changelog"
}

function git_vcs {
    declare path= "$@"

    git_check_path "$path" || return

    fetch_url="$("$git" -C "$GIT_ROOT" config --get remote."$GIT_REMOTE".url)"

    if [ -z "$fetch_url" ]; then
        log_error "Could not get remote fetch URL."
        return 1
    fi

    prefix="$(git_prefix "$path")" || return
    if [ -z "$GIT_DIRTY" ]; then
        tree_suffix="#$GIT_HEAD:$prefix"
    else
        tree_suffix="#:$prefix"
    fi

    output "git+${fetch_url}${tree_suffix%/}"
}

function git_pack {
    # This macro should give the same results content-wise
    # as git_archive on a clean work-tree if you manually
    # set GIT_DIRTY to a non-empty value. Useful for local
    # development because it includes dirty changes in the
    # resulting archive. It auto-switches to git_archive
    # if GIT_DIRTY is empty.
    declare path= dir_name= source_name= "$@"

    if [ -z "$GIT_DIRTY" ]; then
        git_archive_output="$(git_archive "$@")"
        git_archive_retval=$?

        output "$git_archive_output"
        return "$git_archive_retval"
    fi

    git_check_path "$path" || return

    if [ -z "$dir_name" ]; then
        dir_name="$(git_url_path_name "$path")" || return
    fi

    if [ -z "$dir_name" ]; then
        log_error "Could not derive dir_name from remote URL and path."
        return 1
    fi

    if [ -z "$source_name" ]; then
        dirty_flag=

        path_status="$(git_status "$path")" || return
        if [ -n "$path_status" ]; then
            dirty_flag="-dirty"
        fi

        source_name="${dir_name}-${GIT_HEAD_SHORT:-$GIT_BRANCH}${dirty_flag}.tar.gz"
    fi

    if [ -z "$OUTDIR" ]; then
        log_debug "OUTDIR is not set. No action taken."
        output "$source_name"
        return
    fi

    if echo "$GIT_VERSION" | grep -qE '1\.[0-7]\..*$'; then
        log_error "This function is supported up from git 1.8"
        return 1
    fi

    set -o pipefail
    exclude_tmpfile="$(mktemp)"
    # we are using -C "$path" and not -C "GIT_ROOT" because
    # git v1 need to be in submodule context for this to work
    "$git" -C "$path" status --porcelain --ignored -unormal "$path" |
        sed -E -n -e "s+/$++" -e "s+(^!! |^\?\? )+$GIT_ROOT/+p" > "$exclude_tmpfile" || return
    set +o pipefail

    if [ -z "$GIT_LEGACY" ]; then
        # NOTE: git archive keeps empty dirs after omitted submodules. That's why
        # there is sed below. It works because in tar, * matches also dotfiles.
        "$git" -C "$path" submodule -q foreach pwd | sed 's|$|/*|' >> "$exclude_tmpfile" || return
    else
        # we need special handling for legacy git because there the `submodule -q foreach pwd`
        # subcommand can only be invoked inside $GIT_ROOT
        # with this approach in "$exclude_tmpfile", there might
        # be subpath of already excluded paths, which shouldn't matter, however
        submodule_paths="$("$git" -C "$GIT_ROOT" submodule -q foreach --recursive pwd)" || return
        while read -r submodule_path; do
            if is_strict_physical_subpath "$submodule_path" "$(realpath "$path")"; then
                echo "$submodule_path" | sed 's|$|/*|' >> "$exclude_tmpfile"
            fi
        done < <(echo "$submodule_paths")
    fi

    log_info "packing path $path"
    cmd_stdout="$(pack_sources --exclude-from "$exclude_tmpfile" "$path" "$dir_name" "$OUTDIR/$source_name")"
    cmd_retcode=$?

    log_debug "$cmd_stdout"
    rm "$exclude_tmpfile"

    if [ $cmd_retcode -eq 0 ]; then
        log_info "Wrote: $OUTDIR/$source_name"
    else
        log_error "Error during source creation."
        return $cmd_retcode
    fi

    output "$source_name"
}

function git_archive {
    # This macro uses the latest local commit to
    # archive the content. Useful to reproducibly
    # provide a trackable archive content. In pax
    # header, you can find the commit hash.
    declare path= dir_name= source_name= "$@"

    git_check_path "$path" || return

    if [ -z "$GIT_HEAD" ]; then
        log_error "No commits yet. Content cannot be archived."
        return 1
    fi

    if [ -z "$dir_name" ];  then
        dir_name="$(git_url_path_name "$path")" || return
    fi

    if [ -z "$dir_name" ]; then
        log_error "Could not derive dir_name from remote URL and path."
        return 1
    fi

    if [ -z "$source_name" ]; then
        source_name="${dir_name}-${GIT_HEAD_SHORT}.tar.gz"
    fi

    if [ -z "$OUTDIR" ]; then
        log_debug "OUTDIR is not set. No action taken."
        output "$source_name"
        return
    fi

    module_head_path=$(git_module_head_path "$path") || return
    read -r module_head module_path <<< "$module_head_path"

    log_info "archiving $path:"$'\n'"$("$git" -C "$module_path" log -1 "$module_head" --decorate)"
    cmd_stdout="$("$git" -C "$path" archive --prefix="$dir_name/" -o "$OUTDIR/$source_name" "$module_head")"
    cmd_retcode=$?

    log_debug "$cmd_stdout"

    if [ $cmd_retcode -eq 0 ]; then
        log_info "Wrote: $OUTDIR/$source_name"
    else
        log_error "Error during source creation."
        return $cmd_retcode
    fi

    output "$source_name"
}

function git_setup_macro {
    declare path= dir_name= source_indices=0 "$@"

    if [ -z "$dir_name" ]; then
        git_check_path "$path" || return
        dir_name="$(git_url_path_name "$path")" || return
    fi

    if [ -z "$dir_name" ]; then
        log_error "Could not derive dir_name from remote URL and path."
        return 1
    fi

    if [ -z "$source_indices" ]; then
        log_error "source_indices cannot be empty."
        return 1
    fi

    setup_cmd_part=
    while read source_index; do
        if [ -z "$setup_cmd_part" ]; then
            setup_cmd_part="-b $source_index"
        else
            setup_cmd_part="$setup_cmd_part -b $source_index"
        fi
    done < <(echo "$source_indices" | tr ',' '\n')

    output "%setup -T $setup_cmd_part -q -n $dir_name"
}

############## DIR LEVEL FUNCTIONS ##############

function git_dir_name {
    git_check_path "$INPUT_DIR_PATH" || return
    git_name append="$(git_prefix "$INPUT_DIR_PATH" | git_prefix_to_name_suffix)" "$@"
}

function git_dir_version {
    name="$(git_dir_name)" || return
    git_version name="$name" "$@"
}

function git_dir_release {
    name="$(git_dir_name)" || return
    git_release name="$name" "$@"
}

function git_dir_release_branched {
    name="$(git_dir_name)" || return
    git_release_branched name="$name" "$@"
}

function git_dir_changelog {
    name="$(git_dir_name)" || return
    git_changelog name="$name" "$@"
}

function git_dir_vcs {
    git_vcs path="$INPUT_DIR_PATH" "$@"
}

function git_dir_pack {
    git_pack path="$INPUT_DIR_PATH" "$@"
}

function git_dir_archive {
    git_archive path="$INPUT_DIR_PATH" "$@"
}

function git_dir_setup_macro {
    git_setup_macro path="$INPUT_DIR_PATH" "$@"
}

############## CURRENT WORKING DIR FUNCTIONS ##############

function git_cwd_name {
    git_check_path "$PWD" || return
    git_name append="$(git_prefix "$PWD" | git_prefix_to_name_suffix)" "$@"
}

function git_cwd_version {
    name="$(git_cwd_name)" || return
    git_version name="$name" "$@"
}

function git_cwd_release {
    name="$(git_cwd_name)" || return
    git_release name="$name" "$@"
}

function git_cwd_release_branched {
    name="$(git_cwd_name)" || return
    git_release_branched name="$name" "$@"
}

function git_cwd_changelog {
    name="$(git_cwd_name)" || return
    git_changelog name="$name" "$@"
}

function git_cwd_vcs {
    git_vcs path="$PWD" "$@"
}

function git_cwd_pack {
    git_pack path="$PWD" "$@"
}

function git_cwd_archive {
    git_archive path="$PWD" "$@"
}

function git_cwd_setup_macro {
    git_setup_macro path="$PWD" "$@"
}

############## REPO LEVEL FUNCTIONS ##############

function git_repo_name {
    git_name "$@"
}

function git_repo_version {
    name="$(git_repo_name)" || return
    git_version name="$name" "$@"
}

function git_repo_release {
    name="$(git_repo_name)" || return
    git_release name="$name" "$@"
}

function git_repo_release_branched {
    name="$(git_repo_name)" || return
    git_release_branched name="$name" "$@"
}

function git_repo_changelog {
    name="$(git_repo_name)" || return
    git_changelog name="$name" "$@"
}

function git_repo_vcs {
    git_vcs path="$GIT_ROOT" "$@"
}

function git_repo_pack {
    git_pack path="$GIT_ROOT" "$@"
}

function git_repo_archive {
    git_archive path="$GIT_ROOT" "$@"
}

function git_repo_setup_macro {
    git_setup_macro path="$GIT_ROOT" "$@"
}
