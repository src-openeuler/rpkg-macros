# DESCRIPTION:
#
# Source this file to source all the macro definition files at once.

scriptdir="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
self="$(basename "${BASH_SOURCE[0]}")"

for f in $scriptdir/*; do
    if [ "$(basename "$f")" != "$self" ] && [ -f "$f" ]; then
        source "$f"
    fi
done
