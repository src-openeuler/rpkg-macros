export libdir="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATH="$libdir/../macros.d/helpers:$PATH"

source "$libdir"/../macros.d/library/utils.bash

GIT_VERSION="$(/usr/bin/git --version)"
GIT_LEGACY="$(echo "$GIT_VERSION" | grep 'git version 1')"

if [ -z "$GIT_LEGACY" ]; then
    git=/usr/bin/git
else
    git=git
fi

function die {
    echo fail.
    exit 1
}

function skip_test {
    echo skipped.
    exit 0
}

function log_filter {
    grep -Ev -e '^> (env|cmd):' -e 'Wrote: /tmp/' -e 'git_(dir_|cwd_)?(archive|pack): archiving /tmp/'\
    -e 'git_(dir_|cwd_)?pack: packing path /tmp/' -e 'fatal: [nN]ot a git repository' -e '(GIT_DISCOVERY_ACROSS_FILESYSTEM not set)'\
    -e '^Date:' -e '^commit '
}

function run {
    echo '>' "$@";
    eval "$@";
}

function dirty_sub {
    latest_ctime="$(builtin cd "$1"; . "$libdir"/../macros.d/git.bash; utils_encode_decimal "$(git_latest_ctime)")"
    shift && sed -Ei "s/\.dirty\.[a-zA-Z0-9]+/.dirty.$latest_ctime/" "$@"
}

function head_commit_sub {
    full_hash="$("$git" -C "$1" rev-parse HEAD)"
    short_hash="$("$git" -C "$1" rev-parse --short=8 HEAD)"

    shift && sed -Ei -e "s|(\.git\.[0-9]+)\.[a-zA-Z0-9]{8}|\1.$short_hash|" -e "s|#\w{40}:|#$full_hash:|" \
        -e "s|-[a-zA-Z0-9]{8}(-dirty)?.tar.gz$|-$short_hash\1.tar.gz|" "$@"
}

function xsubs {
    sed -Ei -e "s/\.dirty\.[a-zA-Z0-9]+/.dirty.xxxxxx/" \
        -e "s|(\.git\.[0-9]+)\.[a-zA-Z0-9]+|\1.xxxxxxxx|" -e "s|#\w{40}:|#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx:|" \
        -e "s|-[a-zA-Z0-9]{8}(-dirty)?.tar.gz$|-xxxxxxxx\1.tar.gz|" "$@"
}

function prepare_input {
    cat "$1" | sed -Ee 's|^(.+) ::$|\1:\n{{{ \1 }}}\n|' | sed -Ee 's|^(.+) :$|\1:\n{{{ \1 }}}|' | sed -Ee 's|^(.*[^:}])$|\1: {{{ \1 }}}|' > "$2"
}

function prepare_repo {
    "$git" init "$1"
    prepare_identity "$1"
}

function prepare_identity {
    "$git" -C "$1" config user.email 'clime@fedoraproject.org'
    "$git" -C "$1" config user.name 'clime'
}

function generic_test {
    declare preproc_opts= outdir= input= expected_output= expected_log= custom_test= copy_only= skip= "$@"

    if [ -n "$skip" ]; then
        return
    fi

    run "cat $input | preproc $preproc_opts -e PATH=$libdir/../bin:/usr/bin:/bin -e INPUT_DIR_PATH='$(dirname $input)' -s $libdir/../macros.d/all.bash --debug --no-break-on-failure 2>&1 > $outdir/output | log_filter > $outdir/log"

    if [ -n "$copy_only" ]; then
        if [ -n "$expected_log" ]; then
            cp "$outdir/log" "$PWD/$(basename "$expected_log")"
        fi
        if [ -n "$expected_output" ]; then
            cp "$outdir/output" "$PWD/$(basename "$expected_output")"
            xsubs "$PWD/$(basename "$expected_output")"
        fi
        echo copied. && return
    fi

    if [ -n "$input" ] && [ -n "$expected_log" ] && [ -n "$expected_output" ]; then
        run "diff $expected_output $outdir/output || { echo 'LOG DIFF:' && diff $expected_log $outdir/log && die; }"
        run "diff $expected_log $outdir/log || die"
    fi

    if [ -n "$custom_test" ]; then
        run "$custom_test"
    fi

    rm -rf "$outdir"/*
    echo success.
}
